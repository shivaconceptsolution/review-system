from django.db import models
class Register(models.Model):
	emailid = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	mobile = models.CharField(max_length=50)
	review = models.CharField(max_length=50)
	rating = models.IntegerField()

