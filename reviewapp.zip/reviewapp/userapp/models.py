from django.db import models
class Register(models.Model):
	emailid = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	mobile = models.CharField(max_length=50)
	review = models.CharField(max_length=50)
	rating = models.IntegerField()
	def __str__(self):
		return "Email id is "+self.emailid + " Password "+self.password + " Mobile no is "+self.mobile + " review is "+ self.review + " rating is "+str(self.rating)
