from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Register
from django.utils import timezone
def index(request):
	if request.method=="POST":
		s = Register.objects.filter(emailid=request.POST["txtemail"],password=request.POST["txtpass"]).values_list('id')
		
		if s.count()>0:

			print("ID is ",s[0][0])
			request.session["rid"]=s[0][0]
			return redirect('dashboard')
		else:
			return render(request,"userapp/index.html",{"msg":"invalid userid and password"})			
	return render(request,"userapp/index.html")

def dashboard(request):
	if request.session.has_key("rid"):
	 data = Register.objects.get(pk=request.session["rid"])
	 return render(request,"userapp/dashboard.html",{'res':data})
	else:
	  return redirect("/") 
def about(request):
	return render(request,"userapp/about.html")

def account(request):
	if request.method=="POST":
		obj = Register(emailid=request.POST["txtemail"],password=request.POST["txtpass"],mobile=request.POST["txtmobile"],fullname=request.POST["txtfname"],createdate=timezone.now())
		obj.save()
		return render(request,"userapp/account.html",{"msg":" Registration Successfully"})
	return render(request,"userapp/account.html")

def logout(request):
	del request.session['rid']
	return redirect('/')