from django.shortcuts import render,redirect
from .models import Regadmin,CompanyMaster
from django.views import View
class AdminMain(View):
   def post(self,request):
     res = Regadmin.objects.filter(emailid=request.POST["txtemail"],password=request.POST["txtpass"])
     if res.count()>0:
        return redirect('/reviewadmin/dashboard')
     else:
      return render(request,"reviewadmin/index.html",{"msg":"Invalid userid and password"})
   def get(self,request):
     return render(request,"reviewadmin/index.html")

class ADashboard(View):
  def post(self,request):
      obj =  CompanyMaster(companyname=request.POST["txtcompany"])
      obj.save()
      return render(request,"reviewadmin/dashboard.html",{"msg":'company added'})
  def get(self,request):    
      return render(request,"reviewadmin/dashboard.html")