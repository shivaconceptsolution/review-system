from django.urls import path
from reviewadmin.views import AdminMain,ADashboard
from . import views
urlpatterns = [
path('',AdminMain.as_view()),
path('dashboard',ADashboard.as_view())



]