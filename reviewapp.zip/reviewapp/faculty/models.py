from django.db import models
from django.urls import reverse


class FacultyModel(models.Model):
	username = models.CharField(max_length=50)
	password = models.CharField(max_length=50)
	def get_absolute_url(self):
	 return reverse('fac')


class Book(models.Model):
    title = models.CharField(max_length=100)
    isbn = models.CharField(max_length=100, unique=True)
    is_published = models.BooleanField(default=True)
    
    def __str__(self):
        return self.title
