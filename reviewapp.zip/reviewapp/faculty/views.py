from django.shortcuts import render
from django.views.generic.edit import CreateView 
from django.views.generic.list import ListView
from .models import FacultyModel,Book
from django.http import HttpResponse
from .forms import BookCreateForm
class SCSCreate(CreateView): 
    model = FacultyModel 
    fields = ['username', 'password']


def fac(request):
   return HttpResponse("Hello")


class BookCreateView(CreateView):
    def get(self, request, *args, **kwargs):
        context = {'form': BookCreateForm()}
        return render(request, 'faculty/book-create.html', context)

    def post(self, request, *args, **kwargs):
        form = BookCreateForm(request.POST)
        if form.is_valid():
            book = form.save()
            book.save()
            return HttpResponse("Data Submitted Sucessfully")
        return render(request, 'faculty/book-create.html', {'form': form})


class BookList(ListView):
    model =  Book

