from django.urls import path
from .views import SCSCreate,BookList 
from . import views
urlpatterns = [
path('',SCSCreate.as_view()),
path('fac',views.fac,name='fac'),
path('create', views.BookCreateView.as_view(), name='create'),
path('books', BookList.as_view())
]